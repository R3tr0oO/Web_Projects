var querystring = require("querystring");
var fs = require("fs");
var swig = require("swig");
formidable = require("formidable");

//fonction start pour recuperer le nom du visiteur
function start (response, postData) {
  console.log("Le gestionnaire 'menu' est appelé.");
  fs.readFile('saisie_nom.html','utf-8',(error)=>{
      if(error) {
        response.writeHead(500, {"Content-Type": "text/plain"});
        response.write("erreur 404");
        response.end();
      } else {
        response.writeHead(200, {"Content-Type": "text/html"});
        response.write(swig.renderFile('saisie_nom.html', { //utilisation de la bibliothèque swig, afin de placer le nom saisi dans le fochier html
          nom : querystring.parse(postData).text 
      }));
        response.end();
      }
    })
}

//fonction upload pour afficher le nom du visiteur, et afficher les différents oizos 
function upload (response, postData) {
  console.log("Le gestionnaire 'menu' est appelé.");
  fs.readFile('affichage_oizo.html','utf-8',(error)=>{
      if(error) {
        response.writeHead(500, {"Content-Type": "text/plain"});
        response.write("erreur 404");
        response.end();
      } else {
        response.writeHead(200, {"Content-Type": "text/html"});
        response.write(swig.renderFile('affichage_oizo.html', { 
          nom : querystring.parse(postData).text 
      }));
        response.end();
      }
    })
}

//fonction cssstyle pour importer des feuilles css
function cssstyle (response) {
  console.log("Le gestionnaire 'cssstyle' est appelé.");
  fs.readFile("style.css", "binary", function(error, file) {
    if(error) {
      response.writeHead(500, {"Content-Type": "text/plain"});
      response.write("erreur de chargement du css");
      response.end();
    } else {
      response.writeHead(200, {"Content-Type": "text/css"});
      response.write(file, "binary");
      response.end();
    }
  });
}

//fonction qui permet de voir l'image du oiseau 1
function img1 (response) {
  console.log("Le gestionnaire 'img1' est appelé.");
  fs.readFile("martin.png", "binary", function(error, file) {
    if(error) {
      response.writeHead(500, {"Content-Type": "text/plain"});
      response.write(error + "\n");
      response.end();
    } else {
      response.writeHead(200, {"Content-Type": "image/png"});
      response.write(file, "binary");
      response.end();
    }
  });
}

//fonction qui permet de voir l'image du oiseau 2
function img2 (response) {
  console.log("Le gestionnaire 'img2' est appelé.");
  fs.readFile("labbe.png", "binary", function(error, file) {
    if(error) {
      response.writeHead(500, {"Content-Type": "text/plain"});
      response.write(error + "\n");
      response.end();
    } else {
      response.writeHead(200, {"Content-Type": "image/png"});
      response.write(file, "binary");
      response.end();
    }
  });
}

////fonction qui permet de voir l'image du oiseau 3
function img3 (response) {
  console.log("Le gestionnaire 'img3' est appelé.");
  fs.readFile("engoulevent.png", "binary", function(error, file) {
    if(error) {
      response.writeHead(500, {"Content-Type": "text/plain"});
      response.write(error + "\n");
      response.end();
    } else {
      response.writeHead(200, {"Content-Type": "image/png"});
      response.write(file, "binary");
      response.end();
    }
  });
}

//exportation des méthodes pour l'index.js
exports.start = start;
exports.upload = upload;
exports.cssstyle = cssstyle;
exports.img1 = img1;
exports.img2 = img2;
exports.img3 = img3;
