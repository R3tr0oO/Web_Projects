var server = require("./serveur");
var router = require("./routeur");
var requestHandlers = require("./requestHandlers");
var handle = {};

handle["/start"] = requestHandlers.start;
handle["/upload"] = requestHandlers.upload;
handle["/cssstyle"] = requestHandlers.cssstyle;
handle["/img1"] = requestHandlers.img1;
handle["/img2"] = requestHandlers.img2;
handle["/img3"] = requestHandlers.img3;

server.start(router.route, handle);